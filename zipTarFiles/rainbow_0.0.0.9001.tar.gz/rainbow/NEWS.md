rainbow 0.0.9001
All the colors are here!
